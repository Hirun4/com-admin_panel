<?php
session_start();
include_once '../config/config.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../auth/login.php");
    exit;
}

$dateFilter = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$formattedDate = date('F Y', strtotime($dateFilter));

try {
    $stmt = $pdo->prepare("SELECT COUNT(*) AS total_products FROM products");
    $stmt->execute();
    $totalProducts = $stmt->fetch(PDO::FETCH_ASSOC)['total_products'];

    $stmt = $pdo->prepare("SELECT COUNT(*) AS orders_today FROM orders WHERE DATE(created_at) = :dateFilter");
    $stmt->bindParam(':dateFilter', $dateFilter);
    $stmt->execute();
    $ordersToday = $stmt->fetch(PDO::FETCH_ASSOC)['orders_today'];

    $stmt = $pdo->prepare("
        SELECT SUM(oi.selling_price - oi.discount) AS total_revenue 
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        WHERE MONTH(o.created_at) = MONTH(:dateFilter) AND YEAR(o.created_at) = YEAR(:dateFilter)
    ");
    $stmt->bindParam(':dateFilter', $dateFilter);
    $stmt->execute();
    $totalRevenue = $stmt->fetch(PDO::FETCH_ASSOC)['total_revenue'] ?? 0;

    $stmt = $pdo->prepare("
        SELECT 
            SUM(oi.selling_price - oi.discount) AS total_income,
            SUM(oi.selling_price - (SELECT pc.buying_price FROM product_codes pc WHERE pc.code = oi.buying_price_code) - oi.discount) AS profit
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.delivery_method = 'Home' AND DATE(o.created_at) = :dateFilter
    ");
    $stmt->bindParam(':dateFilter', $dateFilter);
    $stmt->execute();
    $homeStats = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("
        SELECT 
            SUM(oi.selling_price - oi.discount) AS total_income,
            SUM(oi.selling_price - (SELECT pc.buying_price FROM product_codes pc WHERE pc.code = oi.buying_price_code) - oi.discount) AS profit
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.delivery_method = 'Courier' AND DATE(o.created_at) = :dateFilter
    ");
    $stmt->bindParam(':dateFilter', $dateFilter);
    $stmt->execute();
    $courierStats = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("
        SELECT p.origin_country, COUNT(*) AS sales_count 
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        JOIN products p ON oi.product_id = p.product_id
        GROUP BY p.origin_country
    ");
    $stmt->execute();
    $salesData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $salesChart = [
        'Vietnam' => 0,
        'India' => 0,
        'China' => 0
    ];

    foreach ($salesData as $row) {
        $country = $row['origin_country'];
        $salesChart[$country] = (int)$row['sales_count'];
    }

    $stmt = $pdo->prepare("
        SELECT p.category, COUNT(*) AS category_count 
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        JOIN products p ON oi.product_id = p.product_id
        GROUP BY p.category
    ");
    $stmt->execute();
    $categoryData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $categoryChart = [
        'Ladies' => 0,
        'Gents' => 0,
        'Kids' => 0
    ];

    foreach ($categoryData as $row) {
        $category = $row['category'];
        $categoryChart[$category] = (int)$row['category_count'];
    }

    $stmt = $pdo->prepare("SELECT spender_name, description, amount, expense_date
                           FROM expenses
                           WHERE DAY(expense_date) BETWEEN 1 AND 15 AND MONTH(expense_date) = MONTH(:dateFilter) 
                           ORDER BY expense_date ASC");
    $stmt->bindParam(':dateFilter', $dateFilter);
    $stmt->execute();
    $expensesFirstHalf = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT spender_name, description, amount, expense_date
                           FROM expenses
                           WHERE DAY(expense_date) BETWEEN 16 AND 31 AND MONTH(expense_date) = MONTH(:dateFilter) 
                           ORDER BY expense_date ASC");
    $stmt->bindParam(':dateFilter', $dateFilter);
    $stmt->execute();
    $expensesSecondHalf = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                <a href="../products/manage_products.php"><i class="fas fa-boxes"></i> Manage Products</a>
                <a href="../orders/manage_orders.php"><i class="fas fa-clipboard-list"></i> Manage Orders</a>
                <a href="../stock/stock_management.php"><i class="fas fa-cogs"></i> Stock Management</a>
                <a href="../expenses/manage_expenses.php"><i class="fas fa-money-bill-wave"></i> Manage Expenses</a>
                <a href="../facebook/view_ads.php"><i class="fab fa-facebook"></i> Facebook Ads</a>
                <a href="monthly_report.php"><i class="fas fa-chart-line"></i> Monthly Report</a>
                <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </aside>

        <main class="main-content">
            <header>
                <h1>Admin Dashboard</h1>
            </header>

            <section class="date-filter">
                <form method="GET" action="index.php">
                    <label for="date">Select Date:</label>
                    <input type="date" id="date" name="date" value="<?= htmlspecialchars($dateFilter) ?>">
                    <button type="submit">Filter</button>
                </form>
            </section>

            <section class="dashboard-stats">
                <div class="stat">
                    <h2>Total Products</h2>
                    <p><?= $totalProducts ?></p>
                </div>
                <div class="stat">
                    <h2>Orders on <?= htmlspecialchars($dateFilter) ?></h2>
                    <p><?= $ordersToday ?></p>
                </div>
                <div class="stat">
                    <h2>Total Revenue for <?= $formattedDate ?></h2>
                    <p>Rs. <?= number_format($totalRevenue, 2) ?></p>
                </div>
            </section>

            <section style="display: flex; justify-content: space-between; margin-top: 30px;">
                <div style="flex: 1; margin-right: 20px;">
                    <h2>Sales by Origin Country</h2>
                    <canvas id="salesChart" style="width: 100%; height: 200px;"></canvas>
                </div>
                <div style="flex: 1;">
                    <h2>Orders by Category</h2>
                    <canvas id="categoryChart" style="width: 80%; max-width: 300px; height: 150px; margin: auto;"></canvas>
                </div>
            </section>

            <section class="dashboard-revenue-profit" style="margin-top: 50px; display: flex; justify-content: space-between; flex-wrap: wrap;">
                <div class="revenue-column">
                    <div class="revenue-item">
                        <h2>Total Profit (Home) on <?= htmlspecialchars($dateFilter) ?></h2>
                        <p>Rs. <?= number_format($homeStats['profit'], 2) ?></p>
                    </div>
                    <div class="revenue-item">
                        <h2>Total Revenue (Home) on <?= htmlspecialchars($dateFilter) ?></h2>
                        <p>Rs. <?= number_format($homeStats['total_income'], 2) ?></p>
                    </div>
                </div>

                <div class="revenue-column">
                    <div class="revenue-item">
                        <h2>Total Profit (Courier) on <?= htmlspecialchars($dateFilter) ?></h2>
                        <p>Rs. <?= number_format($courierStats['profit'], 2) ?></p>
                    </div>
                    <div class="revenue-item">
                        <h2>Total Revenue (Courier) on <?= htmlspecialchars($dateFilter) ?></h2>
                        <p>Rs. <?= number_format($courierStats['total_income'], 2) ?></p>
                    </div>
                </div>
            </section>

            <section class="expenses-table" style="margin-top: 50px;">
                <h2>Expense Records</h2>

                <h3>Expenses (1-15)</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Spender Name</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($expensesFirstHalf)): ?>
                            <?php foreach ($expensesFirstHalf as $expense): ?>
                                <tr>
                                    <td><?= htmlspecialchars($expense['spender_name']) ?></td>
                                    <td><?= htmlspecialchars($expense['description']) ?></td>
                                    <td>Rs. <?= number_format($expense['amount'], 2) ?></td>
                                    <td><?= htmlspecialchars($expense['expense_date']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4">No expenses found for this period.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <h3>Expenses (16-31)</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Spender Name</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($expensesSecondHalf)): ?>
                            <?php foreach ($expensesSecondHalf as $expense): ?>
                                <tr>
                                    <td><?= htmlspecialchars($expense['spender_name']) ?></td>
                                    <td><?= htmlspecialchars($expense['description']) ?></td>
                                    <td>Rs. <?= number_format($expense['amount'], 2) ?></td>
                                    <td><?= htmlspecialchars($expense['expense_date']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4">No expenses found for this period.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <script>
        const ctx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Vietnam', 'India', 'China'],
                datasets: [{
                    label: 'Sales Count',
                    data: [<?= $salesChart['Vietnam'] ?>, <?= $salesChart['India'] ?>, <?= $salesChart['China'] ?>],
                    backgroundColor: ['#3498db', '#e74c3c', '#2ecc71']
                }]
            }
        });

        const categoryCtx = document.getElementById('categoryChart').getContext('2d');
        const categoryChart = new Chart(categoryCtx, {
            type: 'pie',
            data: {
                labels: ['Ladies', 'Gents', 'Kids'],
                datasets: [{
                    label: 'Category Distribution',
                    data: [<?= $categoryChart['Ladies'] ?>, <?= $categoryChart['Gents'] ?>, <?= $categoryChart['Kids'] ?>],
                    backgroundColor: ['#FF69B4', '#2980b9', '#27ae60']
                }]
            }
        });
    </script>
</body>
</html>
