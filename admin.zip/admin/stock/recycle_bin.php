<?php
session_start();
include_once '../config/config.php';

// Ensure the admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Handle Restock Action
if (isset($_GET['restore_stock_id'])) {
    $stock_id = intval($_GET['restore_stock_id']);

    try {
        $stmt = $pdo->prepare("UPDATE stock SET deleted_at = NULL WHERE id = :stock_id");
        $stmt->bindParam(':stock_id', $stock_id, PDO::PARAM_INT);
        $stmt->execute();

        $_SESSION['message'] = "Stock restored successfully.";
        header("Location: recycle_bin.php");
        exit;
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}

// Handle Delete Forever Action
if (isset($_GET['delete_forever_stock_id'])) {
    $stock_id = intval($_GET['delete_forever_stock_id']);

    try {
        $stmt = $pdo->prepare("DELETE FROM stock WHERE id = :stock_id");
        $stmt->bindParam(':stock_id', $stock_id, PDO::PARAM_INT);
        $stmt->execute();

        $_SESSION['message'] = "Stock deleted permanently.";
        header("Location: recycle_bin.php");
        exit;
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}

// Fetch all deleted stocks
try {
    $stmt = $pdo->prepare("SELECT * FROM stock WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC");
    $stmt->execute();
    $deletedStocks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recycle Bin</title>
    <link rel="stylesheet" href="../assets/css/stock.css">
    <!-- Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="../dashboard/index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                <a href="stock_management.php"><i class="fas fa-cogs"></i> Stock Management</a>
                <a href="recycle_bin.php" class="active"><i class="fas fa-trash-alt"></i> Recycle Bin</a>
                <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </aside>

        <main class="main-content">
            <header>
                <h1><i class="fas fa-recycle"></i> Recycle Bin</h1>
            </header>

            <section class="stock-table">
                <h2>Deleted Stocks</h2>
                <?php if (!empty($_SESSION['message'])): ?>
                    <div class="alert">
                        <?= $_SESSION['message']; unset($_SESSION['message']); ?>
                    </div>
                <?php endif; ?>
                <?php if (count($deletedStocks) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Stock Name</th>
                                <th>Purchase Date</th>
                                <th>Amount Purchased</th>
                                <th>Purchase Price (Rs.)</th>
                                <th>Selling Price (Rs.)</th>
                                <th>Deleted At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($deletedStocks as $stock): ?>
                                <tr>
                                    <td><?= htmlspecialchars($stock['stock_name']) ?></td>
                                    <td><?= htmlspecialchars($stock['purchase_date']) ?></td>
                                    <td><?= htmlspecialchars($stock['amount_purchased']) ?></td>
                                    <td>Rs. <?= number_format($stock['purchase_price'], 2) ?></td>
                                    <td>Rs. <?= number_format($stock['selling_price'], 2) ?></td>
                                    <td><?= htmlspecialchars($stock['deleted_at']) ?></td>
                                    <td>
                                        <a href="recycle_bin.php?restore_stock_id=<?= $stock['id'] ?>"><i class="fas fa-undo"></i> Restock</a> |
                                        <a href="recycle_bin.php?delete_forever_stock_id=<?= $stock['id'] ?>" 
                                           onclick="return confirm('Are you sure you want to delete this stock permanently?');"><i class="fas fa-trash"></i> Delete Forever</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No records found in the recycle bin.</p>
                <?php endif; ?>
            </section>
        </main>
    </div>
</body>
</html>
