<?php
session_start();

// Include the database configuration
if (file_exists('../config/config.php')) {
    include_once '../config/config.php';
} else {
    die("Configuration file not found. Please check the path to config.php.");
}

// Ensure the admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../../auth/login.php");
    exit;
}

// Check if the order_id is provided in the URL
if (!isset($_GET['order_id'])) {
    header("Location: manage_orders.php");
    exit;
}

$order_id = intval($_GET['order_id']);

// Fetch order details to delete associated image if any
try {
    $stmt = $pdo->prepare("SELECT product_image FROM orders WHERE order_id = :order_id");
    $stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
    $stmt->execute();
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        header("Location: manage_orders.php");
        exit;
    }

    // Delete associated image if exists
    if (!empty($order['product_image']) && file_exists($order['product_image'])) {
        unlink($order['product_image']);
    }

    // Delete the order from the database
    $stmt = $pdo->prepare("DELETE FROM orders WHERE order_id = :order_id");
    $stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
    $stmt->execute();

    $_SESSION['success_message'] = "Order deleted successfully.";
    header("Location: manage_orders.php");
    exit;
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
