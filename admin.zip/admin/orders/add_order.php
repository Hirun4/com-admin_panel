<?php
session_start();
include_once '../config/config.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../auth/login.php");
    exit;
}

$error = '';
$success = '';

// Fetch countries for the dropdown
try {
    $countries = ['Vietnam', 'China', 'India'];
} catch (PDOException $e) {
    $error = 'Failed to fetch data: ' . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $delivery_method = $_POST['delivery_method'] ?? 'Home';
    $tracking_number = ($delivery_method === 'Courier') ? ($_POST['tracking_number'] ?? uniqid('TRK_', true)) : null;
    $customer_name = ($delivery_method === 'Courier') ? $_POST['customer_name'] ?? '' : null;
    $address = $_POST['address'] ?? '';
    $phone_number1 = $_POST['phone_number1'] ?? '';
    $phone_number2 = ($delivery_method === 'Courier') ? ($_POST['phone_number2'] ?? '') : null;
    $district = $_POST['district'] ?? '';
    $delivery_fee = $_POST['delivery_fee'] ?? 0.00;
    $status = $_POST['status'] ?? 'Pending';
    $return_reason = ($status === 'Returned') ? $_POST['return_reason'] ?? '' : null;
    $products = $_POST['products'] ?? [];

    if (empty($products)) {
        $error = 'No products selected!';
    }

    if (empty($error)) {
        try {
            $pdo->beginTransaction();

            // Insert order details
            $stmtOrder = $pdo->prepare("
                INSERT INTO orders (tracking_number, customer_name, address, phone_number1, phone_number2, district, delivery_method, status, return_reason, delivery_fee, created_at, updated_at)
                VALUES (:tracking_number, :customer_name, :address, :phone_number1, :phone_number2, :district, :delivery_method, :status, :return_reason, :delivery_fee, NOW(), NOW())
            ");
            $stmtOrder->execute([
                ':tracking_number' => $tracking_number,
                ':customer_name' => $customer_name,
                ':address' => $address,
                ':phone_number1' => $phone_number1,
                ':phone_number2' => $phone_number2,
                ':district' => $district,
                ':delivery_method' => $delivery_method,
                ':status' => $status,
                ':return_reason' => $return_reason,
                ':delivery_fee' => $delivery_fee,
            ]);
            $order_id = $pdo->lastInsertId();

            // Prepare statements for order items and stock updates
            $stmtOrderItems = $pdo->prepare("
                INSERT INTO order_items (order_id, product_id, origin_country, size, quantity, buying_price_code, buying_price, selling_price, discount)
                VALUES (:order_id, :product_id, :origin_country, :size, :quantity, :buying_price_code, :buying_price, :selling_price, :discount)
            ");
            $stmtUpdateStock = $pdo->prepare("
                UPDATE product_stock 
                SET quantity = quantity - :quantity 
                WHERE product_id = :product_id AND size = :size AND quantity >= :quantity
            ");
            $stmtUpdateProduct = $pdo->prepare("
                UPDATE products 
                SET stock_quantity = (
                    SELECT SUM(quantity) FROM product_stock WHERE product_id = :product_id
                ),
                stock_status = CASE 
                    WHEN (SELECT SUM(quantity) FROM product_stock WHERE product_id = :product_id) > 0 THEN 'In Stock'
                    ELSE 'Out of Stock'
                END
                WHERE product_id = :product_id
            ");

            // Process each product
            foreach ($products as $product) {
                $buying_price_code = $product['buying_price_code'] ?? null;
                $buying_price = $product['buying_price'] ?? 0;

                if ($buying_price_code) {
                    $stmtPrice = $pdo->prepare("SELECT buying_price FROM product_codes WHERE code = :code");
                    $stmtPrice->execute([':code' => $buying_price_code]);
                    $price_result = $stmtPrice->fetch(PDO::FETCH_ASSOC);

                    if ($price_result) {
                        $buying_price = $price_result['buying_price'];
                    } else {
                        $error = "Invalid buying price code!";
                        break;
                    }
                }

                $stmtOrderItems->execute([
                    ':order_id' => $order_id,
                    ':product_id' => $product['product_id'],
                    ':origin_country' => $product['origin_country'],
                    ':size' => $product['size'],
                    ':quantity' => $product['quantity'],
                    ':buying_price_code' => $buying_price_code,
                    ':buying_price' => $buying_price,
                    ':selling_price' => $product['selling_price'],
                    ':discount' => $product['discount'],
                ]);
                $stmtUpdateStock->execute([
                    ':quantity' => $product['quantity'],
                    ':product_id' => $product['product_id'],
                    ':size' => $product['size'],
                ]);

                if ($stmtUpdateStock->rowCount() === 0) {
                    $error = "Insufficient stock for product ID: {$product['product_id']} and size: {$product['size']}!";
                    $pdo->rollBack();
                    break;
                }

                $stmtUpdateProduct->execute([
                    ':product_id' => $product['product_id'],
                ]);
            }

            if (empty($error)) {
                $pdo->commit();
                $success = 'Order added successfully and stock updated!';
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Order</title>
    <link rel="stylesheet" href="../assets/css/Add_Order.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <h1>Admin Panel</h1>
        <nav>
            <a href="../dashboard/index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="../orders/manage_orders.php"><i class="fas fa-clipboard-list"></i> Manage Orders</a>
            <a href="add_order.php" class="active"><i class="fas fa-plus-circle"></i> Add Order</a>
            <a href="P_P.php"><i class="fas fa-key"></i> Enter Code</a>
            <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </div>
    <div class="main-content">
        <div class="top-bar">Add New Order</div>
        <form method="POST" class="form-container">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <div class="form-group">
                <label for="delivery_method"><i class="fas fa-truck"></i> Delivery Method</label>
                <select id="delivery_method" name="delivery_method" required>
                    <option value="Home" selected>Home</option>
                    <option value="Courier">Courier</option>
                </select>
            </div>

            <div id="courier-fields" style="display: none;">
                <div class="form-group">
                    <label for="tracking_number"><i class="fas fa-hashtag"></i> Tracking Number</label>
                    <input type="text" id="tracking_number" name="tracking_number">
                </div>
                <div class="form-group">
                    <label for="customer_name"><i class="fas fa-user"></i> Customer Name</label>
                    <input type="text" id="customer_name" name="customer_name">
                </div>
                <div class="form-group">
                    <label for="phone_number1"><i class="fas fa-phone"></i> Phone Number 1</label>
                    <input type="text" id="phone_number1" name="phone_number1">
                </div>
                <div class="form-group">
                    <label for="phone_number2"><i class="fas fa-phone"></i> Phone Number 2</label>
                    <input type="text" id="phone_number2" name="phone_number2">
                </div>
                <div class="form-group">
                    <label for="address"><i class="fas fa-map-marker-alt"></i> Address</label>
                    <textarea id="address" name="address"></textarea>
                </div>
                <div class="form-group">
                    <label for="district"><i class="fas fa-city"></i> District</label>
                    <input type="text" id="district" name="district">
                </div>
            </div>

            <div id="delivery_fee_field" style="display: none;">
                <div class="form-group">
                    <label for="delivery_fee"><i class="fas fa-dollar-sign"></i> Delivery Fee</label>
                    <input type="number" id="delivery_fee" name="delivery_fee" step="0.01">
                </div>
            </div>

            <div id="product-fields">
                <div class="product-entry">
                    <div class="form-group">
                        <label for="origin_country"><i class="fas fa-globe"></i> Origin Country</label>
                        <select id="origin_country" name="products[0][origin_country]" onchange="updateCategories(this)" required>
                            <option value="">Select Country</option>
                            <?php foreach ($countries as $country): ?>
                                <option value="<?= htmlspecialchars($country) ?>"><?= htmlspecialchars($country) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="category"><i class="fas fa-tags"></i> Category</label>
                        <select id="category" name="products[0][category]" onchange="updateProducts(this)" required>
                            <option value="">Select Category</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="product_id"><i class="fas fa-box"></i> Product</label>
                        <select id="product_id" name="products[0][product_id]" onchange="updateSizes(this)" required>
                            <option value="">Select Product</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="size"><i class="fas fa-ruler"></i> Size</label>
                        <select id="size" name="products[0][size]" required>
                            <option value="">Select Size</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="quantity"><i class="fas fa-sort-numeric-up"></i> Quantity</label>
                        <input type="number" id="quantity" name="products[0][quantity]" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="buying_price_code"><i class="fas fa-dollar-sign"></i> Buying Price (Code)</label>
                        <input type="text" id="buying_price_code" name="products[0][buying_price_code]" onchange="fetchBuyingPrice()" required>
                    </div>
                    <div class="form-group">
                        <label for="selling_price"><i class="fas fa-dollar-sign"></i> Selling Price</label>
                        <input type="number" id="selling_price" name="products[0][selling_price]" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="discount"><i class="fas fa-percent"></i> Discount</label>
                        <input type="number" id="discount" name="products[0][discount]" step="0.01">
                    </div>
                </div>
            </div>
            <button type="button" onclick="addProductField()">Add Another Product</button>

            <div class="form-group">
                <label for="status"><i class="fas fa-info-circle"></i> Status</label>
                <select id="status" name="status">
                    <option value="Pending">Pending</option>
                    <option value="Shipped">Shipped</option>
                    <option value="Delivered">Delivered</option>
                    <option value="Returned">Returned</option>
                </select>
            </div>

            <button type="submit"><i class="fas fa-plus"></i> Add Order</button>
        </form>
    </div>

    <script>
        const deliveryMethod = document.getElementById('delivery_method');
        const courierFields = document.getElementById('courier-fields');
        const deliveryFeeField = document.getElementById('delivery_fee_field');

        deliveryMethod.addEventListener('change', function () {
            if (this.value === 'Courier') {
                courierFields.style.display = 'block';
                deliveryFeeField.style.display = 'block';
            } else {
                courierFields.style.display = 'none';
                deliveryFeeField.style.display = 'none';
            }
        });

        function fetchBuyingPrice() {
            const code = document.getElementById('buying_price_code').value;
            if (code) {
                fetch(`fetch_buying_price.php?code=${code}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById('buying_price').value = data.buying_price;
                        } else {
                            alert('Invalid code!');
                        }
                    });
            }
        }

        function updateCategories(originField) {
            const country = originField.value;
            const categoryField = originField.closest('.product-entry').querySelector('[name*="[category]"]');
            fetch(`get_categories.php?country=${country}`)
                .then(response => response.json())
                .then(data => {
                    categoryField.innerHTML = '<option value="">Select Category</option>';
                    if (data.categories) {
                        data.categories.forEach(item => {
                            categoryField.innerHTML += `<option value="${item}">${item}</option>`;
                        });
                    }
                });
        }

        function updateProducts(categoryField) {
            const countryField = categoryField.closest('.product-entry').querySelector('[name*="[origin_country]"]');
            const country = countryField.value;
            const category = categoryField.value;
            const productField = categoryField.closest('.product-entry').querySelector('[name*="[product_id]"]');
            fetch(`get_products.php?origin_country=${country}&category=${category}`)
                .then(response => response.json())
                .then(data => {
                    productField.innerHTML = '<option value="">Select Product</option>';
                    if (data.products) {
                        data.products.forEach(item => {
                            productField.innerHTML += `<option value="${item.product_id}">${item.name}</option>`;
                        });
                    }
                });
        }

        function updateSizes(productField) {
            const productId = productField.value;
            const sizeField = productField.closest('.product-entry').querySelector('[name*="[size]"]');
            fetch(`get_sizes.php?product_id=${productId}`)
                .then(response => response.json())
                .then(data => {
                    sizeField.innerHTML = '<option value="">Select Size</option>';
                    if (data.sizes) {
                        data.sizes.forEach(item => {
                            sizeField.innerHTML += `<option value="${item.size}">${item.size}</option>`;
                        });
                    }
                });
        }

        function addProductField() {
            const container = document.getElementById('product-fields');
            const index = container.children.length;
            const entry = `
                <div class="product-entry">
                    <div class="form-group">
                        <label for="origin_country_${index}"><i class="fas fa-globe"></i> Origin Country</label>
                        <select id="origin_country_${index}" name="products[${index}][origin_country]" onchange="updateCategories(this)" required>
                            <option value="">Select Country</option>
                            <?php foreach ($countries as $country): ?>
                                <option value="<?= htmlspecialchars($country) ?>"><?= htmlspecialchars($country) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="category_${index}"><i class="fas fa-tags"></i> Category</label>
                        <select id="category_${index}" name="products[${index}][category]" onchange="updateProducts(this)" required>
                            <option value="">Select Category</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="product_id_${index}"><i class="fas fa-box"></i> Product</label>
                        <select id="product_id_${index}" name="products[${index}][product_id]" onchange="updateSizes(this)" required>
                            <option value="">Select Product</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="size_${index}"><i class="fas fa-ruler"></i> Size</label>
                        <select id="size_${index}" name="products[${index}][size]" required>
                            <option value="">Select Size</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="quantity_${index}"><i class="fas fa-sort-numeric-up"></i> Quantity</label>
                        <input type="number" id="quantity_${index}" name="products[${index}][quantity]" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="buying_price_code_${index}"><i class="fas fa-dollar-sign"></i> Buying Price (Code)</label>
                        <input type="text" id="buying_price_code_${index}" name="products[${index}][buying_price_code]" onchange="fetchBuyingPrice()" required>
                    </div>
                    <div class="form-group">
                        <label for="selling_price_${index}"><i class="fas fa-dollar-sign"></i> Selling Price</label>
                        <input type="number" id="selling_price_${index}" name="products[${index}][selling_price]" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="discount_${index}"><i class="fas fa-percent"></i> Discount</label>
                        <input type="number" id="discount_${index}" name="products[${index}][discount]" step="0.01">
                    </div>
                </div>`;
            container.insertAdjacentHTML('beforeend', entry);
        }
    </script>
</body>
</html>
